
import './App.css';
import Header from './components/Header';
import Accessories from './assets/Desktop-Accessories.jpg'
import ModelS from './assets/Desktop-ModelS.jpeg'
import Model3 from './assets/Desktop-Model3.jpeg'
import ModelX from './assets/Desktop-ModelX.jpeg'
import ModelY from './assets/Desktop-ModelY.jpeg'
import SolarPanel from './assets/Desktop-SolarPanels.jpeg'
import SolarRoof from './assets/Desktop-SolarRoof.jpeg'
import Item from './components/Item';

function App() {
  return (
    <div className="app">
      <Header/>
      <div className="app_itemContainer">
        <Item
        title='Low Cost Solar panels in America'
        desc='Money back garuntee'
        desLink=''      
        backgroundImg={SolarPanel}
        leftBtnTxt='Order Now'
        leftBtnLink=''
        rightBtnTxt='Learn More'
        rightBtnLink=''
        twoButtons='true'
        first
        />
        <Item
        title='Model S'
        desc='Starting at $69,420'
        desLink=''      
        backgroundImg={ModelS}
        leftBtnTxt='Custom Order'
        leftBtnLink=''
        rightBtnTxt='Existing Inventory'
        rightBtnLink=''
        twoButtons='true'
        />
        <Item
        title='Model 3'
        desc='Money back garuntee'
        desLink=''      
        backgroundImg={Model3}
        leftBtnTxt='Custom Order'
        leftBtnLink=''
        rightBtnTxt='Existing Inventory'
        rightBtnLink=''
        twoButtons='true'
        />
        <Item
        title='Model X'
        desc='Money back garuntee'
        desLink=''      
        backgroundImg={ModelX}
        leftBtnTxt='Order Now'
        leftBtnLink=''
        rightBtnTxt='Learn More'
        rightBtnLink=''
        twoButtons='true'
        />
        <Item
        title='Model y'
        desc='Money back garuntee'
        desLink=''      
        backgroundImg={ModelY}
        leftBtnTxt='Order Now'
        leftBtnLink=''
        rightBtnTxt='Learn More'
        rightBtnLink=''
        twoButtons='true'
        />
        <Item
        title='Solar for New Roofs'
        desc='Money back garuntee'
        desLink=''      
        backgroundImg={SolarRoof}
        leftBtnTxt='Order Now'
        leftBtnLink=''
        rightBtnTxt='Learn More'
        rightBtnLink=''
        twoButtons='true'
        />
        <Item
        title='Accessories'
        desc='Money back garuntee'
        desLink=''      
        backgroundImg={Accessories}
        leftBtnTxt='Order Now'
        leftBtnLink=''
        rightBtnTxt='Learn More'
        rightBtnLink=''
        />
      </div>
    </div>
  );
}

export default App;
