
import React, { Component } from 'react';
import axios from 'axios';
import {
  MenuItem, FormControl, Select, Card, CardContent
} from '@material-ui/core';
import Infobox from './Infobox';
import Table from './Table';
import './App.css'
import LineGraph from './LineGraph';
import Mapp from './Mapp';
import 'leaflet/dist/leaflet.css'

export class App extends Component {
  
  constructor() {
    super();
    this.state = {
      countries: [],
      initalCountry: 'Worldwide',
      countryinfo: {},
      tableData: [],
      sortedData:[],
      mapCenter:{lat:34.80746, lng:-40.4796},
      mapZoom:3,
      mapCountries:[]
    }
  }

  componentDidMount() {
    
    axios.get('https://disease.sh/v3/covid-19/countries').then(
      response => {
        console.log(response);
        this.setState({
          countries: response.data,
          tableData: response.data
        })
      }
    )
    axios.get('https://disease.sh/v3/covid-19/all').then(response => {
      console.log('response', response);
      this.setState({
        countryinfo: response.data,
        
      })
    })
  }
  onCountryChange = (event) => {
    let countryCode = event.target.value;
    console.log('countryCode', countryCode)
    this.setState({ initalCountry: countryCode })
    //https://disease.sh/v3/covid-19/all
    //https://disease.sh/v3/covid-19/countries/[COUNTRY_CODE]
    let url = countryCode === 'Worldwide' ? 'https://disease.sh/v3/covid-19/all' :
      `https://disease.sh/v3/covid-19/countries/${countryCode}`;
    axios.get(url).then(response => {
      console.log('Response', response);
      this.setState({
        countryinfo: response.data,
        mapCountries:response.data
      })

    })
  }
  //https://disease.sh/v3/covid-19/countries
  renderList() {
    let countryList = this.state.countries.map(country => {
      return <MenuItem value={country.countryInfo.iso2}>{country.country}</MenuItem>
    })
    return countryList;
  }
  render() {
    return (
      <div className='app'>
        <div className="app__left">
          <div className="app__header">
            <h1>Covid-19 Tracker</h1>
            <FormControl className="app__dropdown">
              <Select variant="outlined" onChange={this.onCountryChange} value={this.state.initalCountry}>
                <MenuItem value='Worldwide'>Worldwide</MenuItem>
                {this.renderList()}
              </Select>
            </FormControl>
          </div>

          <div className="app__stats">
            <Infobox title='Coronavirus Cases' total={this.state.countryinfo.todayCases} cases={this.state.countryinfo.cases} />
            <Infobox title='Recovered Cases' total={this.state.countryinfo.todayRecovered} cases={this.state.countryinfo.recovered} />
            <Infobox title='Deaths' total={this.state.countryinfo.todayDeaths} cases={this.state.countryinfo.deaths} />
          </div>
          <Mapp countries={this.state.mapCountries} center={this.state.mapCenter} zoom={this.state.mapZoom}/>
        </div>
        <div className="app__right">
          <Card>
            <CardContent>
              <h3>List Cases by Country</h3>
              <Table countries={this.state.tableData} />

              <h3>Worldwide New Cases</h3>
              <LineGraph/>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }
}

export default App

