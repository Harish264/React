import React, { Component } from 'react';
import {
   Card,CardContent,Typography
} from '@material-ui/core';

export class Infobox extends Component {
    render() {
        return (
            <div className='infobox'>
                <Card> 
                    <CardContent>
                        <Typography className='infobox__title' color='textSecondary'>
                            {this.props.title}
                        </Typography>
                        <h2 className='infobox__cases'>{this.props.cases}</h2>
                        <Typography className='infobox__total' color='textSecondary'>
                            {this.props.total} Total
                        </Typography>
                    </CardContent>
                </Card>
            </div>
        )
    }
}

export default Infobox
