import React, { Component } from 'react';
import './Table.css';

export class Table extends Component {
    renderList(){
        let tableList=this.props.countries.map(country=>{
            return <tr>
                <td>{country.country}</td>
                <td><strong>{country.cases}</strong></td>
            </tr>
        })
        return tableList
    }
    render() {
        return (
            <div className='table'>
                {this.renderList()}
            </div>
        )
    }
}

export default Table
